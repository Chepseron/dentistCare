
package model;

import java.sql.*;

public class Database {
    private static final String URL = "jdbc:ucanaccess://path_to_database/DentistOffice.accdb";
    private static Connection connection;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(URL);
        }
        return connection;
    }
}
