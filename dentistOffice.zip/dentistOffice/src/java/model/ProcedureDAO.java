package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProcedureDAO {

    // Create a new procedure in the database
    public static void createProcedure(Procedure procedure) throws SQLException {
        try (Connection connection = Database.getConnection()) {
            String query = "INSERT INTO Procedures (procCode, procName, procDesc, cost) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, procedure.getProcCode());
            stmt.setString(2, procedure.getProcName());
            stmt.setString(3, procedure.getProcDesc());
            stmt.setDouble(4, procedure.getCost());
            stmt.executeUpdate();
        }
    }

    // Update an existing procedure in the database
    public static void updateProcedure(Procedure procedure) throws SQLException {
        try (Connection connection = Database.getConnection()) {
            String query = "UPDATE Procedures SET procName = ?, procDesc = ?, cost = ? WHERE procCode = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, procedure.getProcName());
            stmt.setString(2, procedure.getProcDesc());
            stmt.setDouble(3, procedure.getCost());
            stmt.setString(4, procedure.getProcCode());
            stmt.executeUpdate();
        }
    }

    // Delete a procedure from the database
    public static void deleteProcedure(String procCode) throws SQLException {
        try (Connection connection = Database.getConnection()) {
            String query = "DELETE FROM Procedures WHERE procCode = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, procCode);
            stmt.executeUpdate();
        }
    }

    // Fetch all procedures from the database (Read operation)
    public static List<Procedure> getAllProcedures() throws SQLException {
        List<Procedure> procedures = new ArrayList<>();
        try (Connection connection = Database.getConnection()) {
            String query = "SELECT * FROM Procedures";
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                procedures.add(new Procedure(
                    rs.getString("procCode"),
                    rs.getString("procName"),
                    rs.getString("procDesc"),
                    rs.getDouble("cost")
                ));
            }
        }
        return procedures;
    }
}
