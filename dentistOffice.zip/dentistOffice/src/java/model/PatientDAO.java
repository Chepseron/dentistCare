package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {

    public void addPatient(Patient patient) throws SQLException {
        String query = "INSERT INTO Patients (patId, passwd, firstName, lastName, addr, email, insCo) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, patient.getPatId());
            stmt.setString(2, patient.getPasswd());
            stmt.setString(3, patient.getFirstName());
            stmt.setString(4, patient.getLastName());
            stmt.setString(5, patient.getAddr());
            stmt.setString(6, patient.getEmail());
            stmt.setString(7, patient.getInsCo());
            stmt.executeUpdate();
        }
    }

    public List<Patient> getAllPatients() throws SQLException {
        List<Patient> patients = new ArrayList<>();
        String query = "SELECT * FROM Patients";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                patients.add(new Patient(
                        rs.getString("patId"),
                        rs.getString("passwd"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("addr"),
                        rs.getString("email"),
                        rs.getString("insCo")
                ));
            }
        }
        return patients;
    }

    public Patient getPatientById(String patId) throws SQLException {
        String query = "SELECT * FROM Patients WHERE patId = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, patId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Patient(
                            rs.getString("patId"),
                            rs.getString("passwd"),
                            rs.getString("firstName"),
                            rs.getString("lastName"),
                            rs.getString("addr"),
                            rs.getString("email"),
                            rs.getString("insCo")
                    );
                }
            }
        }
        return null;
    }

    public void updatePatient(Patient patient) throws SQLException {
        String query = "UPDATE Patients SET passwd = ?, firstName = ?, lastName = ?, addr = ?, email = ?, insCo = ? WHERE patId = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, patient.getPasswd());
            stmt.setString(2, patient.getFirstName());
            stmt.setString(3, patient.getLastName());
            stmt.setString(4, patient.getAddr());
            stmt.setString(5, patient.getEmail());
            stmt.setString(6, patient.getInsCo());
            stmt.setString(7, patient.getPatId());
            stmt.executeUpdate();
        }
    }

    public void deletePatient(String patId) throws SQLException {
        String query = "DELETE FROM Patients WHERE patId = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, patId);
            stmt.executeUpdate();
        }
    }
}
