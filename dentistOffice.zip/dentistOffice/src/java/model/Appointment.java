
package model;

import java.sql.Timestamp;

public class Appointment {
    private Timestamp apptDateTime;
    private String patId;
    private String dentId;
    private String procCode;

    public Appointment(Timestamp apptDateTime, String patId, String dentId, String procCode) {
        this.apptDateTime = apptDateTime;
        this.patId = patId;
        this.dentId = dentId;
        this.procCode = procCode;
    }

    public Timestamp getApptDateTime() {
        return apptDateTime;
    }

    public void setApptDateTime(Timestamp apptDateTime) {
        this.apptDateTime = apptDateTime;
    }

    public String getPatId() {
        return patId;
    }

    public void setPatId(String patId) {
        this.patId = patId;
    }

    public String getDentId() {
        return dentId;
    }

    public void setDentId(String dentId) {
        this.dentId = dentId;
    }

    public String getProcCode() {
        return procCode;
    }

    public void setProcCode(String procCode) {
        this.procCode = procCode;
    }
}
