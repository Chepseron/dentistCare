package model;

import model.Appointment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {

    public void addAppointment(Appointment appointment) throws SQLException {
        String query = "INSERT INTO Appointments (apptDateTime, patId, dentId, procCode) VALUES (?, ?, ?, ?)";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setTimestamp(1, appointment.getApptDateTime());
            stmt.setString(2, appointment.getPatId());
            stmt.setString(3, appointment.getDentId());
            stmt.setString(4, appointment.getProcCode());
            stmt.executeUpdate();
        }
    }

    public List<Appointment> getAllAppointments() throws SQLException {
        List<Appointment> appointments = new ArrayList<>();
        String query = "SELECT * FROM Appointments";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                appointments.add(new Appointment(
                        rs.getTimestamp("apptDateTime"),
                        rs.getString("patId"),
                        rs.getString("dentId"),
                        rs.getString("procCode")
                ));
            }
        }
        return appointments;
    }

    public Appointment getAppointmentById(int id) throws SQLException {
        String query = "SELECT * FROM Appointments WHERE id = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Appointment(
                            rs.getTimestamp("apptDateTime"),
                            rs.getString("patId"),
                            rs.getString("dentId"),
                            rs.getString("procCode")
                    );
                }
            }
        }
        return null;
    }

    public void updateAppointment(Appointment appointment) throws SQLException {
        String query = "UPDATE Appointments SET apptDateTime = ?, patId = ?, dentId = ?, procCode = ? WHERE apptDateTime = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setTimestamp(1, appointment.getApptDateTime());
            stmt.setString(2, appointment.getPatId());
            stmt.setString(3, appointment.getDentId());
            stmt.setString(4, appointment.getProcCode());
            stmt.setTimestamp(5, appointment.getApptDateTime());
            stmt.executeUpdate();
        }
    }

    public void deleteAppointment(Timestamp apptDateTime) throws SQLException {
        String query = "DELETE FROM Appointments WHERE apptDateTime = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setTimestamp(1, apptDateTime);
            stmt.executeUpdate();
        }
    }
}
