package model;

public class Procedure {
    private String procCode;
    private String procName;
    private String procDesc;
    private double cost;

    // Constructor
    public Procedure(String procCode, String procName, String procDesc, double cost) {
        this.procCode = procCode;
        this.procName = procName;
        this.procDesc = procDesc;
        this.cost = cost;
    }

    // Getter methods
    public String getProcCode() {
        return procCode;
    }

    public String getProcName() {
        return procName;
    }

    public String getProcDesc() {
        return procDesc;
    }

    public double getCost() {
        return cost;
    }

    // Setter methods (optional if you want to update the fields later)
    public void setProcCode(String procCode) {
        this.procCode = procCode;
    }

    public void setProcName(String procName) {
        this.procName = procName;
    }

    public void setProcDesc(String procDesc) {
        this.procDesc = procDesc;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
}
