package model;

import model.Dentist;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Database;

public class DentistDAO {
    
    public void addDentist(Dentist dentist) throws SQLException {
        String query = "INSERT INTO Dentists (id, passwd, firstName, lastName, email, office) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, dentist.getId());
            stmt.setString(2, dentist.getPasswd());
            stmt.setString(3, dentist.getFirstName());
            stmt.setString(4, dentist.getLastName());
            stmt.setString(5, dentist.getEmail());
            stmt.setInt(6, dentist.getOffice());
            stmt.executeUpdate();
        }
    }

    public List<Dentist> getAllDentists() throws SQLException {
        List<Dentist> dentists = new ArrayList<>();
        String query = "SELECT * FROM Dentists";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                dentists.add(new Dentist(
                        rs.getString("id"),
                        rs.getString("passwd"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getInt("office")
                ));
            }
        }
        return dentists;
    }

    public Dentist getDentistById(String id) throws SQLException {
        String query = "SELECT * FROM Dentists WHERE id = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Dentist(
                            rs.getString("id"),
                            rs.getString("passwd"),
                            rs.getString("firstName"),
                            rs.getString("lastName"),
                            rs.getString("email"),
                            rs.getInt("office")
                    );
                }
            }
        }
        return null;
    }

    public void updateDentist(Dentist dentist) throws SQLException {
        String query = "UPDATE Dentists SET passwd = ?, firstName = ?, lastName = ?, email = ?, office = ? WHERE id = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, dentist.getPasswd());
            stmt.setString(2, dentist.getFirstName());
            stmt.setString(3, dentist.getLastName());
            stmt.setString(4, dentist.getEmail());
            stmt.setInt(5, dentist.getOffice());
            stmt.setString(6, dentist.getId());
            stmt.executeUpdate();
        }
    }

    public void deleteDentist(String id) throws SQLException {
        String query = "DELETE FROM Dentists WHERE id = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, id);
            stmt.executeUpdate();
        }
    }
}
