package controller;

import model.AppointmentDAO;
import model.Appointment;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.List;

public class AppointmentServlet extends HttpServlet {

    // Handle all CRUD operations on the same page
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            Timestamp apptDateTime = Timestamp.valueOf(request.getParameter("apptDateTime"));
            String patId = request.getParameter("patId");
            String dentId = request.getParameter("dentId");
            String procCode = request.getParameter("procCode");

            Appointment appointment = new Appointment(apptDateTime, patId, dentId, procCode);
            AppointmentDAO appointmentDAO = new AppointmentDAO();
            try {
                appointmentDAO.addAppointment(appointment);
                response.sendRedirect("appointment.jsp?message=added");
            } catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        } else if ("update".equals(action)) {
            Timestamp apptDateTime = Timestamp.valueOf(request.getParameter("apptDateTime"));
            String patId = request.getParameter("patId");
            String dentId = request.getParameter("dentId");
            String procCode = request.getParameter("procCode");

            Appointment appointment = new Appointment(apptDateTime, patId, dentId, procCode);
            AppointmentDAO appointmentDAO = new AppointmentDAO();
            try {
                appointmentDAO.updateAppointment(appointment);
                response.sendRedirect("appointment.jsp?message=updated");
            } catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        } else if ("delete".equals(action)) {
            Timestamp apptDateTime = Timestamp.valueOf(request.getParameter("apptDateTime"));
            AppointmentDAO appointmentDAO = new AppointmentDAO();
            try {
                appointmentDAO.deleteAppointment(apptDateTime);
                response.sendRedirect("appointment.jsp?message=deleted");
            } catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        }
    }

    // Get all appointments for the list
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AppointmentDAO appointmentDAO = new AppointmentDAO();
        try {
            List<Appointment> appointments = appointmentDAO.getAllAppointments();
            request.setAttribute("appointments", appointments);
            RequestDispatcher dispatcher = request.getRequestDispatcher("appointment.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }
}
