package controller;

import model.PatientDAO;
import model.Patient;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.List;

public class PatientServlet extends HttpServlet {

    // Handle all CRUD operations
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String patId = request.getParameter("patId");
            String passwd = request.getParameter("passwd");
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String addr = request.getParameter("addr");
            String email = request.getParameter("email");
            String insCo = request.getParameter("insCo");

            Patient patient = new Patient(patId, passwd, firstName, lastName, addr, email, insCo);
            PatientDAO patientDAO = new PatientDAO();
            try {
                patientDAO.addPatient(patient);
                response.sendRedirect("patient.jsp?message=added");
            } catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        } else if ("update".equals(action)) {
            String patId = request.getParameter("patId");
            String passwd = request.getParameter("passwd");
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String addr = request.getParameter("addr");
            String email = request.getParameter("email");
            String insCo = request.getParameter("insCo");

            Patient patient = new Patient(patId, passwd, firstName, lastName, addr, email, insCo);
            PatientDAO patientDAO = new PatientDAO();
            try {
                patientDAO.updatePatient(patient);
                response.sendRedirect("patient.jsp?message=updated");
            } catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        } else if ("delete".equals(action)) {
            String patId = request.getParameter("patId");
            PatientDAO patientDAO = new PatientDAO();
            try {
                patientDAO.deletePatient(patId);
                response.sendRedirect("patient.jsp?message=deleted");
            } catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        }
    }

    // Retrieve all patients and display them
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PatientDAO patientDAO = new PatientDAO();
        try {
            List<Patient> patients = patientDAO.getAllPatients();
            request.setAttribute("patients", patients);
            RequestDispatcher dispatcher = request.getRequestDispatcher("patient.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }
}
