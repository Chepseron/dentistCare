package controller;

import model.Procedure;
import model.ProcedureDAO;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class ProcedureServlet extends HttpServlet {
    
    // Handles GET requests to display all procedures (Read)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Fetch all procedures from the database
            List<Procedure> procedures = ProcedureDAO.getAllProcedures();

            // Attach the procedure list to the request as an attribute for the JSP to display
            request.setAttribute("procedures", procedures);

            // Forward the request to the JSP view for display
            RequestDispatcher dispatcher = request.getRequestDispatcher("procedure.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Database error retrieving procedures", e);
        }
    }

    // Handles POST requests for Create, Update, and Delete operations
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");  // Get the action parameter from the form

        try {
            // Handling Create operation
            if ("create".equals(action)) {
                String procCode = request.getParameter("procCode");
                String procName = request.getParameter("procName");
                String procDesc = request.getParameter("procDesc");
                double cost = Double.parseDouble(request.getParameter("cost"));
                
                // Create a new Procedure object
                Procedure newProcedure = new Procedure(procCode, procName, procDesc, cost);
                
                // Insert the new procedure into the database
                ProcedureDAO.createProcedure(newProcedure);

                // Redirect to procedures page with a success message
                response.sendRedirect("procedure.jsp?message=Procedure added successfully");

            } 
            // Handling Update operation
            else if ("update".equals(action)) {
                String procCode = request.getParameter("procCode");
                String procName = request.getParameter("procName");
                String procDesc = request.getParameter("procDesc");
                double cost = Double.parseDouble(request.getParameter("cost"));

                // Create an updated Procedure object
                Procedure updatedProcedure = new Procedure(procCode, procName, procDesc, cost);
                
                // Update the procedure in the database
                ProcedureDAO.updateProcedure(updatedProcedure);

                // Redirect to procedures page with a success message
                response.sendRedirect("procedure.jsp?message=Procedure updated successfully");
            } 
            // Handling Delete operation
            else if ("delete".equals(action)) {
                String procCode = request.getParameter("procCode");
                
                // Delete the procedure from the database
                ProcedureDAO.deleteProcedure(procCode);

                // Redirect to procedures page with a success message
                response.sendRedirect("procedure.jsp?message=Procedure deleted successfully");
            }
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }
}
