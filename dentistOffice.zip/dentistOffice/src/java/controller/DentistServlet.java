package controller;

import model.DentistDAO;
import model.Dentist;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.List;

public class DentistServlet extends HttpServlet {

    // Handle all CRUD operations on the same page
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String id = request.getParameter("id");
            String passwd = request.getParameter("passwd");
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String email = request.getParameter("email");
            int office = Integer.parseInt(request.getParameter("office"));

            Dentist dentist = new Dentist(id, passwd, firstName, lastName, email, office);
            DentistDAO dentistDAO = new DentistDAO();
            try {
                dentistDAO.addDentist(dentist);
                response.sendRedirect("dentist.jsp?message=added");
            } catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        } else if ("update".equals(action)) {
            String id = request.getParameter("id");
            String passwd = request.getParameter("passwd");
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String email = request.getParameter("email");
            int office = Integer.parseInt(request.getParameter("office"));

            Dentist dentist = new Dentist(id, passwd, firstName, lastName, email, office);
            DentistDAO dentistDAO = new DentistDAO();
            try {
                dentistDAO.updateDentist(dentist);
                response.sendRedirect("dentist.jsp?message=updated");
            } catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        } else if ("delete".equals(action)) {
            String id = request.getParameter("id");
            DentistDAO dentistDAO = new DentistDAO();
            try {
                dentistDAO.deleteDentist(id);
                response.sendRedirect("dentist.jsp?message=deleted");
            } catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        }
    }

    // Get all dentists for the list
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        DentistDAO dentistDAO = new DentistDAO();
        try {
            List<Dentist> dentists = dentistDAO.getAllDentists();
            request.setAttribute("dentists", dentists);
            RequestDispatcher dispatcher = request.getRequestDispatcher("dentist.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }
}
