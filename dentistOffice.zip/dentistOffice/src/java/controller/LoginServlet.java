package controller;

import model.Database;
import model.User;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class LoginServlet extends HttpServlet {
    /**
     * Handles POST requests for user login. Authenticates the user and redirects 
     * them to the appropriate dashboard based on their role.
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve username and password from the login form
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection connection = Database.getConnection()) {
            // SQL query to validate the user's credentials
            String query = "SELECT * FROM Users WHERE username = ? AND password = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, username); // Set the username parameter
            stmt.setString(2, password); // Set the password parameter

            ResultSet rs = stmt.executeQuery(); // Execute the query

            // Check if a user record matches the provided credentials
            if (rs.next()) {
                // Create a session for the authenticated user
                HttpSession session = request.getSession();
                session.setAttribute("userId", rs.getInt("id")); // Store user ID in the session
                session.setAttribute("role", rs.getString("role")); // Store user role in the session

                // Redirect user to the appropriate dashboard based on their role
                if (rs.getString("role").equals("patient")) {
                    response.sendRedirect("patient.jsp"); // Redirect to patient dashboard
                } else {
                    response.sendRedirect("dentist.jsp"); // Redirect to dentist dashboard
                }
            } else {
                // If no matching user found, redirect back to login page with an error message
                response.sendRedirect("login.jsp?error=Invalid credentials");
            }
        } catch (SQLException e) {
            // Handle database errors by throwing a ServletException
            throw new ServletException("Database error", e);
        }
    }
}
